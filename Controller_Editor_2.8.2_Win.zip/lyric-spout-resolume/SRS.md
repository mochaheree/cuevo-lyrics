# Software Requirements Specification (SRS)
## Lyric Spout — "ProPresenter Lite" untuk Resolume Arena

| | |
|---|---|
| **Versi dokumen** | 0.1 (draft awal) |
| **Status** | Living document — diperbarui seiring development di Claude Code |
| **Tanggal dibuat** | 2026-08-31 |
| **Pemilik produk** | (kamu) |
| **Baseline kode saat ini** | `lyric-spout-resolume/` (Python, Tkinter, LRCLIB, SpoutGL) |

---

## 1. Pendahuluan

### 1.1 Tujuan Dokumen
Dokumen ini mendefinisikan kebutuhan fungsional dan non-fungsional untuk
**Lyric Spout**, aplikasi desktop Windows yang menampilkan lirik lagu
secara live ke Resolume Arena (lewat Spout), dengan visi jangka panjang
menjadi versi ringan ("lite") dari software presentasi ibadah/live-event
sekelas **ProPresenter**, tapi difokuskan pada satu kasus penggunaan:
**presentasi lirik lagu untuk visual live/VJ setup**, bukan pengganti
penuh ProPresenter.

Dokumen ini ditulis supaya bisa langsung dipakai sebagai acuan kerja di
Claude Code — setiap fitur punya ID requirement, prioritas, dan kriteria
penerimaan yang bisa diturunkan jadi task/issue.

### 1.2 Ruang Lingkup Produk
**Termasuk dalam scope:**
- Pencarian & pengambilan lirik bersinkron waktu dari LRCLIB.
- Penulisan/impor lirik manual (untuk lagu yang tidak ada di LRCLIB).
- Manajemen library lagu & playlist/set list sederhana.
- Kontrol live (play/pause/next/previous/blank) dengan sinkronisasi manual.
- Rendering teks lirik sebagai layer transparan.
- Output ke Resolume Arena lewat Spout (Windows).
- Styling dasar (font, warna, posisi, outline/shadow, background).
- Penyimpanan project/show ke file lokal supaya bisa dibuka lagi.

**Di luar scope (untuk versi ini):**
- Modul non-lirik ala ProPresenter: Bible module, Announcements,
  Countdown/Clock canggih, Props, Camera input, Media playback penuh
  (video/audio player).
- Multi-user/collaborative editing, cloud sync, akun/login.
- Dukungan macOS/Linux untuk output Spout (Spout = Windows-only).
  NDI sebagai alternatif cross-platform dicatat sebagai *future option*
  (lihat §9).
- Mengkloning secara harfiah UI, file format, atau kode ProPresenter.

### 1.3 Catatan Legal & Etis (penting)
"Reverse engineering ProPresenter" di proyek ini dimaknai sebagai:
> Mempelajari **konsep dan fitur yang terlihat sebagai pengguna**
> (workflow live lyrics, playlist, stage display, dsb.) lalu
> mengimplementasikan ulang dari nol dengan arsitektur sendiri —
> **bukan** mendekompilasi binary ProPresenter, membongkar protokol
> jaringan berlisensi mereka, atau mengambil aset/kode mereka.

Implikasi praktis untuk development:
- Jangan gunakan nama, logo, atau branding ProPresenter pada produk ini.
- Jangan mengimpor/mem-parsing format file `.pro6`/`.pro`/dsb. milik
  Renewed Vision tanpa spesifikasi resmi yang dipublikasikan mereka.
- Referensi fitur cukup dari dokumentasi publik/manual pengguna
  ProPresenter, bukan dari source code atau binary mereka.
- Kalau nanti mau interoperasi (mis. baca file `.pro`), itu jadi item
  riset legal tersendiri, di luar scope dokumen ini.

### 1.4 Definisi & Istilah
| Istilah | Arti |
|---|---|
| **Spout** | Teknologi Windows untuk berbagi tekstur GPU antar aplikasi (video real-time). |
| **NDI** | Network Device Interface — alternatif Spout yang jalan lintas platform lewat jaringan. |
| **LRC** | Format teks lirik dengan timestamp per baris, mis. `[00:17.12] baris lirik`. |
| **LRCLIB** | Layanan API publik penyedia lirik synced/plain, gratis tanpa API key. |
| **Show / Set list** | Kumpulan lagu yang diurutkan untuk satu sesi tampil. |
| **Slide** | Satu unit tampilan (di produk ini: satu baris/bait lirik). |
| **Operator view / Stage display** | Tampilan kontrol terpisah untuk operator (bukan yang disiarkan ke penonton). |
| **Cue** | Satu aksi trigger (next slide, blank, ganti lagu) yang bisa dipicu manual/remote. |

### 1.5 Referensi
- LRCLIB API — https://lrclib.net
- SpoutGL (Python) — https://github.com/jlai/Python-SpoutGL
- Resolume Arena — dokumentasi resmi Resolume (Sources > Spout)
- Baseline kode: `README.md` di root repo ini (v0.1)

---

## 2. Deskripsi Umum

### 2.1 Perspektif Produk
Aplikasi berdiri sendiri (bukan plugin Resolume), berkomunikasi dengan
Resolume secara satu arah lewat Spout sebagai "virtual video source".
Tidak ada dependency ke internal Resolume selain protokol Spout itu
sendiri.

```
+------------------+     HTTP      +-----------+
|  Lyric Spout App | <-----------> |  LRCLIB   |
|  (Windows)       |               +-----------+
|                  |
|  [GUI] [Engine]  |     Spout     +-----------------+
|  [Renderer] ------------------->| Resolume Arena    |
+------------------+   (GPU tex)  +-----------------+
```

### 2.2 Fungsi Utama Produk (ringkas)
1. Cari & muat lirik (online via LRCLIB, atau input manual/impor `.lrc`).
2. Susun playlist/set list dari lagu-lagu yang sudah dimuat.
3. Kontrol tampilan live: play/pause/next/prev/blank, koreksi sync.
4. Render & kirim frame ke Resolume lewat Spout secara kontinu.
5. Simpan & buka kembali project (show file lokal).
6. (Fase lanjut) Kontrol jarak jauh via keyboard shortcut / MIDI / OSC.

### 2.3 Kelas Pengguna
| Kelas | Kebutuhan utama |
|---|---|
| **Operator solo** (kasus utama) | Cepat cari lagu, tampil, koreksi sync sambil live, tanpa training rumit. |
| **VJ / visual artist** | Kontrol tampilan lirik menyatu dengan komposisi visual lain di Resolume. |
| **Tim ibadah/event kecil** | Siapkan set list sebelumnya, tinggal jalan pas hari-H. |

### 2.4 Lingkungan Operasi
- **OS:** Windows 10/11 64-bit (wajib untuk fitur Spout).
- **Runtime:** Python 3.9+ (baseline saat ini) — boleh dievaluasi ulang
  di Claude Code kalau butuh migrasi ke stack lain untuk performa/UI
  (lihat §9 Roadmap, item arsitektur).
- **Target:** Resolume Arena versi apa pun yang mendukung Spout receiver.
- **Koneksi internet:** dibutuhkan untuk pencarian LRCLIB; fitur lirik
  manual/lokal harus tetap berfungsi offline.

### 2.5 Batasan Desain & Implementasi
- Spout = Windows-only → arsitektur output harus terisolasi di satu
  modul (`spout_output.py`) supaya bagian lain (pencarian, parsing,
  playlist, UI) tetap testable di OS non-Windows.
- LRCLIB API publik, tanpa API key, **tidak ada rate limit resmi
  didokumentasikan**, tapi tetap kirim `User-Agent` yang jelas dan
  jangan polling berlebihan (hormati fair-use layanan gratis).
- Font rendering bergantung pada font TTF yang tersedia di sistem
  (fallback ke font bawaan Pillow kalau tidak ketemu — kualitas rendah,
  harus diperbaiki di fase styling).

### 2.6 Asumsi & Dependensi
- Audio/musik diputar oleh aplikasi/perangkat lain (Spotify, DJ set,
  live band, dsb.) — aplikasi ini **tidak** memutar audio, hanya
  menyinkronkan teks secara manual terhadap waktu berjalan.
- Resolume Arena berjalan di komputer yang sama (Spout adalah
  local-machine texture sharing, bukan jaringan).

---

## 3. Baseline Implementasi Saat Ini (v0.1)

Sudah diimplementasikan dan berjalan (dasar untuk lanjutan development):

| Modul | Fungsi | Status |
|---|---|---|
| `lrclib_client.py` | `search()`, `get_by_id()`, `get_exact()` ke LRCLIB API | ✅ Selesai |
| `lrc_parser.py` | `parse_lrc()`, `find_current_line()` (binary search) | ✅ Selesai + teruji |
| `player_state.py` | State play/pause/seek/offset, thread-safe | ✅ Selesai + teruji |
| `spout_output.py` | Render lirik ke RGBA transparan (Pillow) + kirim via SpoutGL | 🔄 Direvisi (v0.2): dari mode single-line jadi **mode scroll multi-baris ala Musixmatch** dengan animasi transisi (`MultiLineLyricRenderer`). Belum teruji di Windows nyata. |
| `app.py` / `main.py` | GUI Tkinter: cari, muat, kontrol, start/stop Spout | ✅ Selesai (MVP single-song) |

> **Perubahan v0.2 (lihat §4.4):** mode tampilan output diubah dari
> "satu baris polos" menjadi **scroll multi-baris ala Musixmatch** —
> baris aktif ditonjolkan, baris sekitarnya mengecil/memudar, dan
> perpindahan antar baris dianimasikan halus. Ini menggantikan asumsi
> "single-line" pada draf SRS sebelumnya (REQ-F-OUT-03/04 kini **Must**,
> bukan lagi **Should**).

**Keterbatasan v0.1 yang jadi starting point requirement fase berikut:**
- Tidak ada penyimpanan/persistence (setiap buka app, mulai dari nol).
- Tidak ada playlist — hanya satu lagu aktif dalam satu waktu.
- Tidak ada input lirik manual/offline — 100% bergantung LRCLIB.
- Styling sebagian besar masih hardcoded (parameter konstruktor di kode,
  belum ada panel pengaturan visual di GUI — lihat REQ-F-STYLE-* dan
  REQ-F-OUT-05).
- Tidak ada operator/stage view terpisah — GUI kontrol == satu-satunya
  window.
- Tidak ada remote control (keyboard shortcut global, MIDI, OSC).

---

## 4. Requirement Fungsional

Format ID: `REQ-F-<area>-<nomor>`. Prioritas MoSCoW: **M**ust,
**S**hould, **C**ould, **W**on't (untuk versi ini).

### 4.1 Lyrics Source & Library (`LIB`)

| ID | Requirement | Prioritas |
|---|---|---|
| REQ-F-LIB-01 | Sistem **harus** bisa mencari lagu di LRCLIB berdasarkan judul (+ artis opsional) dan menampilkan hasil beserta status ketersediaan synced lyrics. | M *(selesai)* |
| REQ-F-LIB-02 | Sistem **harus** bisa memuat synced lyrics dari hasil pencarian ke player aktif. | M *(selesai)* |
| REQ-F-LIB-03 | Sistem **harus** menyediakan editor lirik manual: user bisa ketik/tempel teks lirik + set timestamp per baris (atau import file `.lrc` lokal), untuk lagu yang tidak ada di LRCLIB. | M |
| REQ-F-LIB-04 | Sistem **harus** menyimpan lagu yang sudah dimuat/diedit ke **library lokal** (file JSON), supaya tidak perlu cari ulang tiap sesi. | M |
| REQ-F-LIB-05 | Sistem **harus** bisa mengedit ulang timestamp lirik yang sudah dimuat (mis. geser semua baris +N detik sekaligus, untuk kasus versi rekaman beda). | S |
| REQ-F-LIB-06 | Sistem **sebaiknya** punya pencarian lokal di dalam library (bukan hanya LRCLIB) berdasarkan judul/artis. | S |
| REQ-F-LIB-07 | Sistem **boleh** mendukung impor massal dari folder berisi banyak file `.lrc`. | C |

### 4.2 Show / Playlist Management (`SET`)

| ID | Requirement | Prioritas |
|---|---|---|
| REQ-F-SET-01 | Sistem **harus** bisa membuat **Show/Set list**: daftar lagu terurut untuk satu sesi tampil. | M |
| REQ-F-SET-02 | Sistem **harus** bisa menambah, menghapus, dan mengurutkan ulang (drag/tombol naik-turun) lagu dalam satu Show. | M |
| REQ-F-SET-03 | Sistem **harus** bisa berpindah cepat ke lagu berikutnya/sebelumnya dalam Show tanpa lewat pencarian ulang. | M |
| REQ-F-SET-04 | Sistem **harus** menyimpan Show ke file (`.showproject.json` atau sejenis) yang bisa dibuka kembali persis seperti terakhir disimpan. | M |
| REQ-F-SET-05 | Sistem **sebaiknya** menampilkan progres Show (lagu ke berapa dari berapa) di GUI kontrol. | S |

### 4.3 Live Playback & Control (`PLAY`)

| ID | Requirement | Prioritas |
|---|---|---|
| REQ-F-PLAY-01 | Sistem **harus** mendukung Play/Pause/Stop terhadap jam internal lirik (sudah ada). | M *(selesai)* |
| REQ-F-PLAY-02 | Sistem **harus** mendukung seek ke posisi tertentu via slider (sudah ada). | M *(selesai)* |
| REQ-F-PLAY-03 | Sistem **harus** mendukung koreksi offset sync manual saat live (sudah ada, `±0.1s/±0.5s`). | M *(selesai)* |
| REQ-F-PLAY-04 | Sistem **harus** punya tombol/hotkey **"Blank"** yang langsung mengosongkan output (transparan penuh) tanpa mengubah posisi waktu — untuk jeda/transisi antar lagu. | M |
| REQ-F-PLAY-05 | Sistem **harus** punya mode navigasi manual **per-baris** (tombol Next Line / Previous Line) sebagai alternatif dari mode auto-timestamp, untuk kasus lagu tanpa tempo tetap (acapella, rubato, dsb.) — ini mirip mekanisme "klik untuk lanjut slide" ala ProPresenter. | M |
| REQ-F-PLAY-06 | Sistem **sebaiknya** mendukung keyboard shortcut global (spasi = play/pause, panah = next/prev line, `B` = blank) minimal saat window aplikasi fokus. | S |
| REQ-F-PLAY-07 | Sistem **boleh** mendukung shortcut global system-wide (aktif walau window lain sedang fokus) — berguna kalau operator kerja dari layar berbeda. | C |

### 4.4 Rendering & Output (`OUT`)

| ID | Requirement | Prioritas |
|---|---|---|
| REQ-F-OUT-01 | Sistem **harus** merender lirik ke frame RGBA transparan dan mengirimkannya ke Resolume via Spout secara kontinu (sudah ada). | M *(selesai)* |
| REQ-F-OUT-02 | Sistem **harus** hanya menggambar ulang frame saat tampilan berubah (teks/baris aktif berganti, ATAU sedang dalam animasi transisi antar baris) — bukan setiap frame tanpa alasan — untuk efisiensi CPU (sudah ada, disesuaikan untuk mode scroll di v0.2). | M *(selesai)* |
| REQ-F-OUT-03 | Sistem **harus** menganimasikan perpindahan baris aktif secara halus (bukan potongan instan) dengan durasi transisi yang bisa dikonfigurasi (default ±550ms, easing ease-out), supaya terasa "hidup" di layar. | M *(v0.2 — selesai)* |
| REQ-F-OUT-04 | Sistem **harus** menampilkan lirik bergaya **scroll seperti Musixmatch**: beberapa baris tampil sekaligus (default 2 baris sebelum + baris aktif + 2 baris sesudah), baris aktif ditonjolkan (ukuran font & opacity lebih besar), baris di sekitarnya mengecil dan memudar makin jauh jaraknya, dan baris yang mepet tepi atas/bawah kanvas ikut memudar (alpha) supaya tidak terpotong tegas. | M *(v0.2 — selesai, direvisi dari mode single-line di v0.1)* |
| REQ-F-OUT-05 | Sistem **sebaiknya** menyediakan pengaturan dari GUI untuk jumlah baris konteks (sebelum/sesudah), kecepatan transisi, dan jarak antar baris — tanpa perlu edit kode (saat ini masih parameter konstruktor `SpoutOutputThread`/`MultiLineLyricRenderer`). | S |
| REQ-F-OUT-06 | Sistem **boleh** menambahkan output NDI sebagai alternatif Spout untuk kebutuhan lintas mesin/jaringan. | C |
| REQ-F-OUT-07 | Sistem **boleh** mendukung banyak Spout sender sekaligus (mis. output terpisah untuk teks vs untuk background), untuk fleksibilitas compositing di Resolume. | C |

### 4.5 Styling & Template (`STYLE`)

| ID | Requirement | Prioritas |
|---|---|---|
| REQ-F-STYLE-01 | Sistem **harus** menyediakan pengaturan dari GUI (bukan edit kode) untuk: font, ukuran, warna teks, warna outline, tebal outline, posisi vertikal/horizontal teks. | M |
| REQ-F-STYLE-02 | Sistem **harus** menyimpan pengaturan style sebagai **Template** yang bisa dipakai ulang lintas Show. | S |
| REQ-F-STYLE-03 | Sistem **sebaiknya** menyediakan beberapa Template siap pakai (preset) untuk mempercepat setup pertama kali. | S |
| REQ-F-STYLE-04 | Sistem **boleh** mendukung background layer opsional di belakang teks (warna solid/gambar) yang ikut dikirim lewat Spout yang sama atau sender terpisah. | C |

### 4.6 Operator / Stage Display (`OPS`)

| ID | Requirement | Prioritas |
|---|---|---|
| REQ-F-OPS-01 | Sistem **sebaiknya** memisahkan tampilan **kontrol operator** (daftar lagu, tombol, slider) dari **preview output** (persis seperti yang dikirim ke Spout), supaya operator bisa cek visual tanpa buka Resolume. | S |
| REQ-F-OPS-02 | Sistem **boleh** menampilkan baris "berikutnya" di panel operator (seperti stage display ProPresenter), supaya operator siap-siap sebelum next line/lagu. | C |

### 4.7 Remote Control (`RC`)

| ID | Requirement | Prioritas |
|---|---|---|
| REQ-F-RC-01 | Sistem **boleh** menerima trigger via **OSC** (Open Sound Control) untuk next/prev/blank/play/pause — memudahkan integrasi dengan controller fisik atau software lain (termasuk Resolume sendiri yang punya OSC out). | C |
| REQ-F-RC-02 | Sistem **boleh** menerima trigger via **MIDI** (mis. dari MIDI foot controller) untuk aksi yang sama seperti di atas. | C |

### 4.8 Settings & Persistence (`CFG`)

| ID | Requirement | Prioritas |
|---|---|---|
| REQ-F-CFG-01 | Sistem **harus** mengingat pengaturan terakhir (nama Spout sender, resolusi, font size default) antar sesi. | M |
| REQ-F-CFG-02 | Sistem **harus** menyimpan lokasi library & show file default yang bisa dikonfigurasi user. | S |

---

## 5. Data Model (usulan)

Disimpan sebagai file JSON lokal (folder `data/` di root project, bisa
disesuaikan). Skema di bawah ini adalah **usulan awal**, boleh
disempurnakan saat implementasi di Claude Code.

### 5.1 `Song`
```json
{
  "id": "uuid-v4",
  "title": "The Chain",
  "artist": "Fleetwood Mac",
  "album": "Rumours",
  "duration_sec": 271,
  "source": "lrclib | manual",
  "lrclib_id": 151738,
  "lines": [
    { "time_sec": 27.93, "text": "Listen to the wind blow" },
    { "time_sec": 30.88, "text": "Watch the sun rise" }
  ],
  "created_at": "2026-08-31T10:00:00Z",
  "updated_at": "2026-08-31T10:00:00Z"
}
```

### 5.2 `Show` (Set list)
```json
{
  "id": "uuid-v4",
  "name": "Minggu Pagi - 31 Agustus",
  "song_ids": ["uuid-song-1", "uuid-song-2"],
  "template_id": "uuid-template-default",
  "created_at": "2026-08-31T10:00:00Z"
}
```

### 5.3 `Template` (Style)
```json
{
  "id": "uuid-v4",
  "name": "Default White Outline",
  "font_path": null,
  "active_font_size": 64,
  "text_color": [255, 255, 255, 255],
  "outline_color": [0, 0, 0, 255],
  "outline_width": 3,
  "layout": "scroll_multiline",
  "vertical_anchor_ratio": 0.5,
  "context_lines_before": 2,
  "context_lines_after": 2,
  "line_spacing_ratio": 1.55,
  "size_falloff": 0.22,
  "opacity_falloff": 0.32,
  "edge_fade_ratio": 0.18,
  "transition_ms": 550
}
```
Field `layout` disiapkan sebagai enum (`scroll_multiline` | `single_line`)
supaya mode single-line v0.1 tetap bisa dipilih sebagai opsi alternatif,
bukan dihapus total — beberapa operator mungkin tetap lebih suka gaya
lower-third yang lebih minimalis untuk visual tertentu.

### 5.4 `Settings` (global, per instalasi)
```json
{
  "spout_sender_name": "LyricSpout",
  "output_width": 1920,
  "output_height": 1080,
  "fps": 30,
  "default_template_id": "uuid-template-default",
  "library_path": "./data/library.json",
  "shows_path": "./data/shows/"
}
```

---

## 6. Requirement Non-Fungsional

| ID | Kategori | Requirement |
|---|---|---|
| REQ-NF-01 | Performance | Frame yang dikirim ke Spout **harus** stabil di target fps (default 30) tanpa drop terlihat, dengan CPU usage rendah saat teks tidak berubah (leverage caching frame yang sudah ada). |
| REQ-NF-02 | Latency | Perubahan baris lirik (baik dari auto-timestamp maupun manual next/prev) **harus** terlihat di Resolume dalam < 100ms. |
| REQ-NF-03 | Reliability | Jika koneksi ke LRCLIB gagal/timeout, aplikasi **tidak boleh** crash — tampilkan pesan error dan tetap bisa lanjut pakai lirik manual/library lokal. |
| REQ-NF-04 | Reliability | Thread Spout output **harus** bisa dihentikan bersih (tanpa hang) saat user klik Stop atau tutup aplikasi. |
| REQ-NF-05 | Usability | Operator baru **harus** bisa cari → muat → tampilkan lagu pertama dalam < 2 menit tanpa baca manual (target onboarding). |
| REQ-NF-06 | Portability | Modul non-Spout (pencarian, parsing, playlist, data model) **harus** tetap bisa dijalankan/diuji di non-Windows untuk kemudahan development di Claude Code, walau fitur Spout sendiri hanya aktif di Windows. |
| REQ-NF-07 | Maintainability | Setiap modul baru **harus** punya pemisahan tanggung jawab yang jelas (mengikuti pola modul v0.1: client/parser/state/renderer/UI terpisah), supaya mudah di-unit-test. |
| REQ-NF-08 | Security/Privacy | Tidak ada data pribadi yang dikirim ke pihak ketiga selain query judul lagu ke LRCLIB (publik, tanpa akun). |
| REQ-NF-09 | Legal/Compliance | Aplikasi **harus** mengirim header `User-Agent` yang jelas ke LRCLIB (sudah ada) dan tidak melakukan polling berlebihan di luar aksi user. |

---

## 7. Kebutuhan Antarmuka Eksternal

| Interface | Tipe | Detail |
|---|---|---|
| LRCLIB API | REST/HTTP, JSON | `GET /api/search`, `GET /api/get/{id}`, `GET /api/get` — tanpa API key |
| Spout (Resolume) | Local GPU texture share (SpoutGL) | Sender name dikonfigurasi user; frame RGBA |
| Filesystem | Baca/tulis JSON lokal | Library lagu, Show, Template, Settings |
| (Fase lanjut) OSC | UDP, protokol OSC | Untuk remote trigger next/prev/blank |
| (Fase lanjut) MIDI | MIDI over USB/virtual port | Untuk remote trigger dari foot controller |
| (Fase lanjut) NDI | Network video | Alternatif Spout untuk setup multi-mesin |

---

## 8. Arsitektur Modul (Target, Lanjutan dari Baseline)

```
lyric-spout-resolume/
├── main.py
├── app.py                  # GUI utama (dipecah lagi per fase: tabs)
├── lrclib_client.py        # (ada) integrasi LRCLIB
├── lrc_parser.py           # (ada) parsing & pencarian baris
├── player_state.py         # (ada) state playback per-song
├── spout_output.py         # (ada) render + kirim Spout
├── data/
│   ├── library.py          # BARU: CRUD Song ke library.json
│   ├── shows.py            # BARU: CRUD Show/Set list
│   └── templates.py        # BARU: CRUD Template/style
├── ui/
│   ├── library_view.py     # BARU: tab pencarian + library
│   ├── show_view.py        # BARU: tab set list & urutan lagu
│   ├── style_view.py       # BARU: tab pengaturan style/template
│   └── operator_view.py    # BARU (opsional): window preview terpisah
└── remote/
    ├── osc_listener.py     # BARU (opsional, fase lanjut)
    └── midi_listener.py    # BARU (opsional, fase lanjut)
```

Prinsip: modul `data/*` dan `remote/*` tidak boleh bergantung pada
`tkinter` maupun `SpoutGL` secara langsung, supaya tetap testable
lintas platform (selaras REQ-NF-06/07).

---

## 9. Roadmap & Prioritas Pengerjaan

| Fase | Fokus | Requirement terkait |
|---|---|---|
| **Fase 0 — Selesai** | MVP single-song, single-line, kontrol manual, output Spout | Baseline §3 |
| **Fase 1 — Persistence & Lirik Manual** | Library lokal, editor lirik manual/impor `.lrc`, Settings tersimpan | REQ-F-LIB-03/04, REQ-F-CFG-* |
| **Fase 2 — Show/Set list** | Susun & simpan playlist, navigasi next/prev lagu, mode next-line manual | REQ-F-SET-*, REQ-F-PLAY-04/05 |
| **Fase 3 — Styling dari GUI** | Panel pengaturan visual, Template tersimpan & reusable | REQ-F-STYLE-* |
| **Fase 4 — Operator Experience** | Preview terpisah, hotkey, pengaturan scroll dari GUI (baris konteks/kecepatan transisi) | REQ-F-OPS-*, REQ-F-PLAY-06, REQ-F-OUT-05 |
| **Fase 5 — Remote & Interop** | OSC/MIDI trigger, evaluasi NDI, multi-sender | REQ-F-RC-*, REQ-F-OUT-06/07 |

Rekomendasi urutan kerja di Claude Code: selesaikan Fase 1 & 2 dulu
(paling terasa manfaatnya untuk pemakaian nyata di lapangan — bisa
nyimpen lagu & bikin set list), baru masuk ke styling dan fitur
"ProPresenter-like" lain yang sifatnya penyempurnaan pengalaman.

---

## 10. Risiko & Isu Terbuka

| Risiko | Dampak | Mitigasi |
|---|---|---|
| Spout hanya jalan di Windows | Development di mesin non-Windows tidak bisa full-test | Isolasi modul Spout (sudah dilakukan); pertimbangkan CI/manual test checklist khusus Windows |
| LRCLIB bisa berubah skema/limit sewaktu-waktu (masih "beta") | Fitur pencarian bisa rusak mendadak | Bungkus semua panggilan API dengan error handling jelas (sudah ada `LrcLibError`); tambahkan fallback ke library lokal |
| Ketergantungan font sistem (`arial.ttf`) | Tampilan tidak konsisten di semua Windows | Fase Styling: bundel font open-source default di dalam repo |
| Scope creep menuju "ProPresenter penuh" | Timeline molor, kompleksitas naik drastis | Tetap disiplin ke scope §1.2; modul baru (Bible, media, dsb.) eksplisit di luar scope kecuali direvisi dokumen ini |
| Isu trademark/branding kalau nama produk terlalu mirip ProPresenter | Potensi masalah hukum ringan | Pilih nama produk sendiri yang jelas berbeda; hindari klaim "compatible with ProPresenter" |

---

## 11. Kriteria Penerimaan Fase 1 (contoh, siap jadi task Claude Code)

Supaya dokumen ini langsung actionable, berikut contoh breakdown untuk
fase berikutnya:

- [ ] `data/library.py`: fungsi `add_song()`, `get_song(id)`,
      `list_songs()`, `delete_song(id)`, baca/tulis ke `library.json`.
- [ ] Tab "Editor Lirik Manual" di GUI: textarea untuk tempel teks lirik
      + tombol "tandai waktu baris ini" (mirip cara kerja software
      karaoke sederhana) saat lagu direferensikan diputar manual.
- [ ] Import `.lrc` lokal dari file picker, parse pakai `lrc_parser.py`
      yang sudah ada (tidak perlu ubah parser).
- [ ] `Settings` disimpan ke `settings.json`, dibaca saat start-up
      (nama sender, resolusi, path library default).
- [ ] Update `app.py` supaya lagu yang sudah dimuat otomatis tersimpan
      ke library (opsional: tombol eksplisit "Simpan ke Library").

---

## 12. Lampiran: Glosarium Singkat ProPresenter (untuk konteks fitur)

Untuk referensi saat menerjemahkan fitur ke versi lite:

- **Playlist** → di sini disebut **Show/Set list**.
- **Slide** → di sini satu **baris lirik**.
- **Stage Display** → panel terpisah untuk operator, lihat REQ-F-OPS-*.
- **Clear/Blank** → REQ-F-PLAY-04.
- **Trigger via MIDI/remote** → REQ-F-RC-*.
- **Themes/Templates** → REQ-F-STYLE-02/03.

Semua padanan di atas adalah **kesamaan konsep tingkat fitur**, bukan
kesamaan implementasi/kode — sesuai catatan legal di §1.3.
