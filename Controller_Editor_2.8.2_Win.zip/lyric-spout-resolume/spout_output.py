"""
Output ke Resolume Arena lewat Spout.

Cara kerja:
  1. Bikin OpenGL context lewat pygame (Spout butuh context GL aktif di
     thread yang memanggilnya). Window-nya dibuat kecil (256x256) dan
     TIDAK ditutup selama proses berjalan -- window ini cuma "wadah"
     context GPU, ukurannya tidak ada hubungannya dengan resolusi frame
     lirik yang dikirim.
  2. Render BEBERAPA baris lirik sekaligus ke gambar RGBA transparan
     pakai Pillow, bergaya scroll seperti Musixmatch: baris aktif
     ditonjolkan (besar, tegas), baris-baris di sekitarnya mengecil dan
     memudar sesuai jaraknya, dan posisinya berpindah dengan animasi
     halus (bukan potong instan) tiap kali baris aktif berganti.
  3. Kirim buffer gambar itu ke Spout sender lewat SpoutGL.sendImage().
  4. Di Resolume Arena: klik kanan pada layer/clip -> Sources -> Spout,
     lalu pilih nama sender ini (default "LyricSpout").

CATATAN PENTING: modul ini hanya benar-benar bisa mengirim ke Spout di
Windows, karena Spout adalah teknologi sharing tekstur GPU khusus
Windows. Kalau SpoutGL/pygame belum terpasang atau kamu bukan di
Windows, SPOUT_AVAILABLE akan False dan aplikasi akan kasih tahu lewat
GUI -- tapi pencarian lirik & logika playback tetap bisa dites di OS
apa pun.
"""
import threading
import time

from PIL import Image, ImageDraw, ImageFont

try:
    import pygame
    import SpoutGL
    from OpenGL import GL
    SPOUT_AVAILABLE = True
except ImportError:
    SPOUT_AVAILABLE = False


def _ease_out_cubic(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return 1.0 - (1.0 - t) ** 3


class MultiLineLyricRenderer:
    """
    Menggambar beberapa baris lirik sekaligus ke buffer RGBA transparan,
    dengan baris aktif di posisi `displayed_pos` ditonjolkan dan baris
    lain di sekitarnya mengecil/memudar sesuai jarak -- gaya scroll ala
    Musixmatch. `displayed_pos` boleh berupa angka pecahan (mis. 2.4)
    saat sedang dalam animasi transisi antar baris.
    """

    def __init__(self, width, height, font_path=None, active_font_size=64,
                 text_color=(255, 255, 255, 255), outline_color=(0, 0, 0, 255),
                 outline_width=3, context_before=2, context_after=2,
                 line_spacing_ratio=1.55, vertical_anchor_ratio=0.5,
                 edge_fade_ratio=0.18, size_falloff=0.22, opacity_falloff=0.32):
        self.width = width
        self.height = height
        self.text_color = text_color
        self.outline_color = outline_color
        self.outline_width = outline_width
        self.context_before = context_before
        self.context_after = context_after
        self.line_spacing = int(active_font_size * line_spacing_ratio)
        self.vertical_anchor_y = height * vertical_anchor_ratio
        self.edge_fade_px = height * edge_fade_ratio
        self.size_falloff = size_falloff
        self.opacity_falloff = opacity_falloff
        self.active_font_size = active_font_size

        candidates = [font_path] if font_path else ["arial.ttf", "Arial.ttf", "DejaVuSans-Bold.ttf"]
        self._font_path = None
        for candidate in candidates:
            if not candidate:
                continue
            try:
                ImageFont.truetype(candidate, active_font_size)
                self._font_path = candidate
                break
            except OSError:
                continue
        if self._font_path is None:
            print("[MultiLineLyricRenderer] Font TTF tidak ketemu, pakai font bawaan Pillow "
                  "(ukurannya tetap kecil). Set font_path ke file .ttf yang valid kalau perlu.")
        self._font_cache = {}

    def _font(self, size: int):
        size = max(8, size)
        font = self._font_cache.get(size)
        if font is None:
            if self._font_path:
                font = ImageFont.truetype(self._font_path, size)
            else:
                font = ImageFont.load_default()
            self._font_cache[size] = font
        return font

    def _style_at_distance(self, dist: float):
        """
        dist = jarak (boleh pecahan) antara indeks baris ini dan posisi
        baris aktif saat ini. dist=0 -> baris aktif (paling besar/terang).
        """
        d = abs(dist)
        size = max(12, int(self.active_font_size * max(0.0, 1.0 - d * self.size_falloff)))
        opacity = max(0.0, 1.0 - d * self.opacity_falloff)
        weight_bold = d < 0.5
        return size, opacity, weight_bold

    def _edge_fade(self, y: float) -> float:
        """Baris yang mepet tepi atas/bawah kanvas ikut memudar (alpha), supaya
        tidak terpotong tegas di batas frame."""
        top_dist = y
        bottom_dist = self.height - y
        nearest = min(top_dist, bottom_dist)
        if nearest >= self.edge_fade_px:
            return 1.0
        return max(0.0, nearest / self.edge_fade_px)

    def render(self, lines, displayed_pos: float) -> bytes:
        """
        lines: list of (time_sec, text) -- hasil parse_lrc().
        displayed_pos: indeks baris yang sedang berada di tengah (pecahan
        saat animasi berjalan; -1 kalau belum ada baris yang aktif).
        """
        img = Image.new("RGBA", (self.width, self.height), (0, 0, 0, 0))
        if not lines:
            return img.tobytes("raw", "RGBA")

        draw = ImageDraw.Draw(img)
        window = self.context_before + self.context_after + 2  # buffer ekstra utk animasi
        center_idx = round(displayed_pos)
        lo = max(0, center_idx - window)
        hi = min(len(lines) - 1, center_idx + window)

        for i in range(lo, hi + 1):
            dist = i - displayed_pos
            size, opacity, bold = self._style_at_distance(dist)
            if opacity <= 0.02:
                continue

            y_center = self.vertical_anchor_y + dist * self.line_spacing
            if y_center < -size or y_center > self.height + size:
                continue

            opacity *= self._edge_fade(y_center)
            if opacity <= 0.02:
                continue

            text = lines[i][1]
            if not text:
                continue

            font = self._font(size)
            bbox = draw.textbbox((0, 0), text, font=font)
            text_w = bbox[2] - bbox[0]
            text_h = bbox[3] - bbox[1]
            x = (self.width - text_w) / 2 - bbox[0]
            y = y_center - text_h / 2 - bbox[1]

            alpha = int(255 * opacity)
            fill = (*self.text_color[:3], min(self.text_color[3], alpha))
            outline_fill = (*self.outline_color[:3], min(self.outline_color[3], alpha))

            ow = self.outline_width if dist == 0 or abs(dist) < 1 else max(1, self.outline_width - 1)
            if ow > 0:
                for dx in range(-ow, ow + 1):
                    for dy in range(-ow, ow + 1):
                        if dx == 0 and dy == 0:
                            continue
                        draw.text((x + dx, y + dy), text, font=font, fill=outline_fill)
            draw.text((x, y), text, font=font, fill=fill)

        return img.tobytes("raw", "RGBA")


class SpoutOutputThread(threading.Thread):
    """
    Thread terpisah yang membuka koneksi Spout dan terus mengirim frame
    lirik (mode scroll multi-baris) berdasarkan PlayerState yang
    di-share dengan GUI Tkinter.
    """

    def __init__(self, player_state, sender_name="LyricSpout",
                 width=1920, height=1080, fps=30, font_size=64, font_path=None,
                 text_color=(255, 255, 255, 255), context_before=2, context_after=2,
                 transition_ms=550):
        super().__init__(daemon=True)
        self.player_state = player_state
        self.sender_name = sender_name
        self.width = width
        self.height = height
        self.fps = fps
        self.font_size = font_size
        self.font_path = font_path
        self.text_color = text_color
        self.context_before = context_before
        self.context_after = context_after
        self.transition_ms = transition_ms
        self._stop_event = threading.Event()
        self.status = "belum dimulai"

    def stop(self):
        self._stop_event.set()

    def run(self):
        if not SPOUT_AVAILABLE:
            self.status = ("SpoutGL/pygame belum terpasang, atau bukan di Windows. "
                            "Jalankan: pip install SpoutGL pygame PyOpenGL")
            return

        try:
            pygame.init()
            # window kecil cuma buat pegang context OpenGL -- jangan ditutup manual
            pygame.display.set_mode((256, 256), pygame.OPENGL | pygame.DOUBLEBUF)
            pygame.display.set_caption(f"Lyric Spout aktif - jangan ditutup ({self.sender_name})")

            renderer = MultiLineLyricRenderer(
                self.width, self.height, font_path=self.font_path,
                active_font_size=self.font_size, text_color=self.text_color,
                context_before=self.context_before, context_after=self.context_after,
            )

            with SpoutGL.SpoutSender() as sender:
                sender.setSenderName(self.sender_name)
                self.status = f"mengirim ke Resolume sebagai Spout sender '{self.sender_name}'"

                frame_interval = 1.0 / self.fps
                transition_sec = self.transition_ms / 1000.0

                last_lines_id = None
                last_active_index = None
                anim_start_time = None
                anim_start_pos = 0.0
                anim_target_pos = 0.0
                displayed_pos = -1.0
                frame_bytes = renderer.render([], -1.0)
                force_redraw = True

                while not self._stop_event.is_set():
                    start = time.perf_counter()
                    pygame.event.pump()  # supaya window kecil tidak dianggap "not responding"

                    lines = self.player_state.get_lines()
                    lines_id = id(lines) if lines else None
                    current_time = self.player_state.get_current_time()
                    active_index = self.player_state.get_active_index(current_time)

                    if lines_id != last_lines_id:
                        # lagu baru dimuat -- langsung lompat, tanpa animasi
                        displayed_pos = float(active_index)
                        anim_start_time = None
                        last_lines_id = lines_id
                        last_active_index = active_index
                        force_redraw = True
                    elif active_index != last_active_index:
                        anim_start_pos = displayed_pos
                        anim_target_pos = float(active_index)
                        anim_start_time = time.perf_counter()
                        last_active_index = active_index

                    animating = False
                    if anim_start_time is not None:
                        elapsed_anim = time.perf_counter() - anim_start_time
                        t = min(1.0, elapsed_anim / transition_sec) if transition_sec > 0 else 1.0
                        eased = _ease_out_cubic(t)
                        displayed_pos = anim_start_pos + (anim_target_pos - anim_start_pos) * eased
                        animating = t < 1.0
                        if not animating:
                            anim_start_time = None

                    if animating or force_redraw:
                        frame_bytes = renderer.render(lines, displayed_pos)
                        force_redraw = False

                    sender.sendImage(frame_bytes, self.width, self.height, GL.GL_RGBA, False, 0)
                    sender.setFrameSync(self.sender_name)

                    elapsed = time.perf_counter() - start
                    time.sleep(max(0.0, frame_interval - elapsed))

            pygame.quit()
            self.status = "berhenti"
        except Exception as exc:  # tampilkan error apapun ke GUI lewat status, bukan crash diam-diam
            self.status = f"error: {exc}"
