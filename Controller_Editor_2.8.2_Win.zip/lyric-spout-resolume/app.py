"""
GUI utama: cari & muat lirik dari LRCLIB, kontrol playback manual
(play/pause/seek + koreksi sync), dan tombol mulai/berhenti kirim ke
Resolume Arena lewat Spout.

Jalankan: python main.py
"""
import queue
import threading
import tkinter as tk
from tkinter import ttk, messagebox

import lrclib_client
from lrc_parser import parse_lrc
from player_state import PlayerState
from spout_output import SpoutOutputThread, SPOUT_AVAILABLE


def format_time(seconds: float) -> str:
    seconds = max(0.0, seconds)
    m = int(seconds // 60)
    s = seconds - m * 60
    return f"{m:02d}:{s:05.2f}"


class LyricSpoutApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Lyric Spout untuk Resolume Arena")
        self.root.geometry("660x640")

        self.player_state = PlayerState()
        self.spout_thread = None
        self.search_results = []
        self.ui_queue = queue.Queue()
        self._dragging_slider = False

        self._build_ui()
        self.root.after(100, self._poll_queue)
        self.root.after(200, self._update_playback_ui)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---------------- UI LAYOUT ----------------

    def _build_ui(self):
        pad = {"padx": 8, "pady": 4}

        # --- 1. Pencarian ---
        search_frame = ttk.LabelFrame(self.root, text="1. Cari lirik di LRCLIB")
        search_frame.pack(fill="x", **pad)

        ttk.Label(search_frame, text="Judul lagu").grid(row=0, column=0, sticky="w")
        self.track_entry = ttk.Entry(search_frame, width=28)
        self.track_entry.grid(row=0, column=1, sticky="we", padx=4)

        ttk.Label(search_frame, text="Artis (opsional)").grid(row=0, column=2, sticky="w")
        self.artist_entry = ttk.Entry(search_frame, width=18)
        self.artist_entry.grid(row=0, column=3, sticky="we", padx=4)

        self.search_btn = ttk.Button(search_frame, text="Cari", command=self._on_search)
        self.search_btn.grid(row=0, column=4, padx=4)
        search_frame.columnconfigure(1, weight=1)

        self.result_list = tk.Listbox(search_frame, height=6)
        self.result_list.grid(row=1, column=0, columnspan=5, sticky="we", pady=(6, 0))

        self.load_btn = ttk.Button(search_frame, text="Muat lirik terpilih",
                                    command=self._on_load_selected)
        self.load_btn.grid(row=2, column=0, columnspan=5, sticky="we", pady=4)

        # --- 2. Playback manual ---
        play_frame = ttk.LabelFrame(self.root, text="2. Kontrol playback manual")
        play_frame.pack(fill="x", **pad)

        btns = ttk.Frame(play_frame)
        btns.pack(fill="x")
        ttk.Button(btns, text="\u25b6 Play", command=self.player_state.play).pack(side="left", padx=4, pady=4)
        ttk.Button(btns, text="\u23f8 Pause", command=self.player_state.pause).pack(side="left", padx=4)
        ttk.Button(btns, text="\u23f9 Stop", command=self.player_state.stop).pack(side="left", padx=4)

        self.time_label = ttk.Label(play_frame, text="00:00.00 / 00:00.00")
        self.time_label.pack(anchor="w", padx=4)

        self.seek_scale = ttk.Scale(play_frame, from_=0, to=100, orient="horizontal")
        self.seek_scale.pack(fill="x", padx=4, pady=4)
        self.seek_scale.bind("<ButtonPress-1>", lambda e: setattr(self, "_dragging_slider", True))
        self.seek_scale.bind("<ButtonRelease-1>", self._on_seek_release)

        offset_frame = ttk.Frame(play_frame)
        offset_frame.pack(fill="x", pady=(0, 4))
        ttk.Label(offset_frame, text="Koreksi sinkron manual:").pack(side="left", padx=4)
        for label, delta in [("-0.5s", -0.5), ("-0.1s", -0.1), ("+0.1s", 0.1), ("+0.5s", 0.5)]:
            ttk.Button(offset_frame, text=label,
                       command=lambda d=delta: self._on_nudge(d)).pack(side="left", padx=2)
        self.offset_label = ttk.Label(offset_frame, text="offset: +0.00s")
        self.offset_label.pack(side="left", padx=8)

        self.preview_label = ttk.Label(play_frame, text="(belum ada lirik dimuat)",
                                        font=("Segoe UI", 14, "bold"), foreground="#333")
        self.preview_label.pack(fill="x", padx=4, pady=(4, 8))

        # --- 3. Output Spout ---
        spout_frame = ttk.LabelFrame(self.root, text="3. Output ke Resolume via Spout")
        spout_frame.pack(fill="x", **pad)

        row = ttk.Frame(spout_frame)
        row.pack(fill="x")
        ttk.Label(row, text="Nama Spout sender").pack(side="left", padx=4)
        self.sender_name_entry = ttk.Entry(row, width=18)
        self.sender_name_entry.insert(0, "LyricSpout")
        self.sender_name_entry.pack(side="left", padx=4)

        ttk.Label(row, text="Ukuran").pack(side="left", padx=4)
        self.width_entry = ttk.Entry(row, width=6)
        self.width_entry.insert(0, "1920")
        self.width_entry.pack(side="left")
        ttk.Label(row, text="x").pack(side="left")
        self.height_entry = ttk.Entry(row, width=6)
        self.height_entry.insert(0, "1080")
        self.height_entry.pack(side="left", padx=(0, 4))

        ttk.Label(row, text="Font size").pack(side="left", padx=4)
        self.font_size_entry = ttk.Entry(row, width=5)
        self.font_size_entry.insert(0, "64")
        self.font_size_entry.pack(side="left")

        btn_row = ttk.Frame(spout_frame)
        btn_row.pack(fill="x", pady=4)
        self.start_spout_btn = ttk.Button(btn_row, text="Mulai kirim ke Resolume",
                                           command=self._on_start_spout)
        self.start_spout_btn.pack(side="left", padx=4)
        self.stop_spout_btn = ttk.Button(btn_row, text="Berhenti", command=self._on_stop_spout,
                                          state="disabled")
        self.stop_spout_btn.pack(side="left", padx=4)

        self.spout_status_label = ttk.Label(spout_frame, text="Status: belum aktif")
        self.spout_status_label.pack(anchor="w", padx=4, pady=(0, 6))

        if not SPOUT_AVAILABLE:
            ttk.Label(
                spout_frame,
                text=("\u26a0 SpoutGL/pygame belum terpasang, atau kamu tidak sedang di Windows.\n"
                      "Jalankan: pip install SpoutGL pygame PyOpenGL Pillow requests"),
                foreground="#b00020", wraplength=600, justify="left"
            ).pack(anchor="w", padx=4, pady=4)

    # ---------------- LOGIKA PENCARIAN ----------------

    def _on_search(self):
        track = self.track_entry.get().strip()
        artist = self.artist_entry.get().strip()
        if not track:
            messagebox.showinfo("Info", "Isi dulu judul lagunya.")
            return

        self.search_btn.config(state="disabled", text="Mencari...")
        self.result_list.delete(0, "end")

        def worker():
            try:
                results = lrclib_client.search(track_name=track, artist_name=artist)
            except Exception as exc:
                self.ui_queue.put(lambda: self._on_search_error(exc))
                return
            self.ui_queue.put(lambda: self._on_search_done(results))

        threading.Thread(target=worker, daemon=True).start()

    def _on_search_done(self, results):
        self.search_btn.config(state="normal", text="Cari")
        self.search_results = results
        if not results:
            self.result_list.insert("end", "(tidak ada hasil)")
            return
        for item in results:
            dur = int(item.get("duration") or 0)
            if item.get("syncedLyrics"):
                tag = "synced"
            elif item.get("plainLyrics"):
                tag = "plain saja"
            else:
                tag = "kosong"
            label = (f"{item.get('trackName', '?')} \u2014 {item.get('artistName', '?')} "
                      f"[{dur // 60}:{dur % 60:02d}] ({tag})")
            self.result_list.insert("end", label)

    def _on_search_error(self, exc):
        self.search_btn.config(state="normal", text="Cari")
        messagebox.showerror("Gagal mencari", str(exc))

    def _on_load_selected(self):
        sel = self.result_list.curselection()
        if not sel or not self.search_results:
            messagebox.showinfo("Info", "Pilih salah satu hasil pencarian dulu.")
            return
        item = self.search_results[sel[0]]
        synced = item.get("syncedLyrics")
        if not synced:
            messagebox.showwarning(
                "Tidak ada synced lyrics",
                "Lagu ini tidak punya lirik bersinkron waktu di LRCLIB, "
                "jadi tidak bisa dipakai untuk mode auto-scroll di sini."
            )
            return
        parsed = parse_lrc(synced)
        duration = float(item.get("duration") or (parsed[-1][0] + 5 if parsed else 60))
        self.player_state.load_lyrics(parsed, duration=duration)
        self.seek_scale.config(to=duration)
        messagebox.showinfo("Berhasil", f"Lirik '{item.get('trackName')}' dimuat "
                                          f"({len(parsed)} baris).")

    # ---------------- LOGIKA PLAYBACK ----------------

    def _on_seek_release(self, event):
        self._dragging_slider = False
        self.player_state.seek(self.seek_scale.get())

    def _on_nudge(self, delta):
        self.player_state.nudge_offset(delta)
        self.offset_label.config(text=f"offset: {self.player_state.get_offset():+.2f}s")

    def _update_playback_ui(self):
        pos = self.player_state.get_raw_position()
        dur = self.player_state.get_duration()
        self.time_label.config(text=f"{format_time(pos)} / {format_time(dur)}")
        if not self._dragging_slider:
            self.seek_scale.set(pos)

        current_line = self.player_state.get_line_for_time(self.player_state.get_current_time())
        self.preview_label.config(text=current_line or "\u266a ...")

        self.root.after(150, self._update_playback_ui)

    # ---------------- LOGIKA SPOUT ----------------

    def _on_start_spout(self):
        if not SPOUT_AVAILABLE:
            messagebox.showerror(
                "SpoutGL tidak tersedia",
                "Pastikan kamu menjalankan ini di Windows dan sudah install:\n"
                "pip install SpoutGL pygame PyOpenGL"
            )
            return
        try:
            width = int(self.width_entry.get())
            height = int(self.height_entry.get())
            font_size = int(self.font_size_entry.get())
        except ValueError:
            messagebox.showerror("Input salah", "Ukuran dan font size harus berupa angka.")
            return

        name = self.sender_name_entry.get().strip() or "LyricSpout"
        self.spout_thread = SpoutOutputThread(
            self.player_state, sender_name=name,
            width=width, height=height, font_size=font_size,
        )
        self.spout_thread.start()
        self.start_spout_btn.config(state="disabled")
        self.stop_spout_btn.config(state="normal")
        self.root.after(500, self._poll_spout_status)

    def _poll_spout_status(self):
        if self.spout_thread and self.spout_thread.is_alive():
            self.spout_status_label.config(text=f"Status: {self.spout_thread.status}")
            self.root.after(1000, self._poll_spout_status)
        elif self.spout_thread:
            self.spout_status_label.config(text=f"Status: {self.spout_thread.status}")

    def _on_stop_spout(self):
        if self.spout_thread:
            self.spout_thread.stop()
            self.spout_thread.join(timeout=2)
        self.start_spout_btn.config(state="normal")
        self.stop_spout_btn.config(state="disabled")
        self.spout_status_label.config(text="Status: dihentikan")

    # ---------------- UTIL ----------------

    def _poll_queue(self):
        try:
            while True:
                callback = self.ui_queue.get_nowait()
                callback()
        except queue.Empty:
            pass
        self.root.after(100, self._poll_queue)

    def _on_close(self):
        self._on_stop_spout()
        self.root.destroy()


def main():
    root = tk.Tk()
    LyricSpoutApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
