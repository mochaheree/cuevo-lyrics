# Lyric Spout untuk Resolume Arena

Aplikasi desktop kecil (Python + Tkinter) untuk menampilkan lirik lagu
(diambil dari [LRCLIB](https://lrclib.net)) sebagai teks berjalan
transparan, dikirim langsung ke Resolume Arena lewat **Spout**.

Alur kerjanya:

```
[Kamu ketik judul lagu] -> [LRCLIB API: cari & ambil synced lyrics]
        -> [Parser LRC: baris + timestamp]
        -> [Kontrol manual: Play/Pause/Seek/Offset]
        -> [Render beberapa baris + animasi scroll ke RGBA transparan]
        -> [SpoutGL sendImage] -> [Resolume Arena: Sources > Spout]
```

Sync-nya **manual**: kamu tekan Play saat lagu mulai, lalu kalau lirik
terasa mendahului/tertinggal, tinggal klik tombol koreksi `-0.1s` /
`+0.1s` dst sampai pas. Tampilan lirik: **mode scroll ala Musixmatch**
— beberapa baris tampil sekaligus (default 2 sebelum + baris aktif +
2 sesudah), baris aktif ditonjolkan (lebih besar & tegas), baris
lain mengecil/memudar sesuai jaraknya, dan tiap kali baris aktif
berganti posisinya berpindah dengan animasi halus (bukan potongan
instan). Bukan karaoke per-kata — highlight-nya di level baris.

## Kebutuhan sistem

- **Windows** (wajib untuk fitur Spout — Spout adalah teknologi
  sharing tekstur GPU khusus Windows; ini tidak akan bisa mengirim ke
  Resolume kalau dijalankan di macOS/Linux).
- Python 3.9+ terpasang di Windows.
- Resolume Arena (versi apa pun yang mendukung Spout, yaitu hampir
  semua versi modern di Windows).

## Instalasi

```powershell
cd lyric-spout-resolume
pip install -r requirements.txt
```

Kalau instalasi `SpoutGL` gagal, biasanya karena versi Python 32-bit vs
64-bit tidak cocok dengan wheel yang tersedia — pastikan pakai Python
64-bit resmi dari python.org.

## Menjalankan

```powershell
python main.py
```

Akan muncul window GUI dengan 3 bagian:

### 1. Cari lirik di LRCLIB
Isi judul lagu (dan artis kalau mau lebih presisi), klik **Cari**.
Hasil pencarian muncul di daftar, dengan tanda `(synced)` kalau lagu
itu punya lirik bersinkron waktu (yang dibutuhkan aplikasi ini), atau
`(plain saja)` / `(kosong)` kalau tidak — pilih yang `(synced)`, lalu
klik **Muat lirik terpilih**.

### 2. Kontrol playback manual
- **Play / Pause / Stop** — mengatur jam internal aplikasi.
- Slider — geser untuk lompat ke posisi tertentu (mis. kalau lagu di
  DJ deck/player lain sudah berjalan beberapa detik sebelum kamu
  sempat klik Play di sini).
- **Koreksi sinkron manual** (`-0.5s`/`-0.1s`/`+0.1s`/`+0.5s`) — dipakai
  live kalau lirik terasa sedikit maju/mundur dibanding audio asli.
  Offset ini berlaku terus sampai kamu ubah lagi atau muat lagu baru.
- Baris di bawahnya adalah **preview** teks yang sedang/​akan dikirim
  ke Resolume, supaya kamu bisa cek tanpa harus lihat layar Resolume.

### 3. Output ke Resolume via Spout
- **Nama Spout sender** — nama yang akan muncul di daftar sumber Spout
  Resolume (default `LyricSpout`).
- **Ukuran** — resolusi frame yang dikirim (default 1920x1080,
  transparan, teks ditaruh dekat bagian bawah frame).
- **Font size** — ukuran huruf.
- Klik **Mulai kirim ke Resolume**. Akan muncul window kecil
  berjudul "Lyric Spout aktif - jangan ditutup" — window ini cuma
  wadah context GPU, **biarkan saja terbuka** (boleh diminimize),
  jangan di-close selama kamu masih butuh outputnya.

## Menghubungkan ke Resolume Arena

1. Di Resolume Arena, klik kanan pada sebuah **layer/clip** (atau slot
   kosong).
2. Pilih **Sources > Spout**.
3. Pilih sender dengan nama yang sama seperti yang kamu isi di
   aplikasi ini (default `LyricSpout`).
4. Lirik akan muncul sebagai clip dengan background transparan —
   tinggal ditumpuk (composite) di atas visual/video lain sesuai
   kebutuhan set kamu.

## Struktur kode

| File | Isi |
|---|---|
| `lrclib_client.py` | Panggilan HTTP ke API LRCLIB (search, get). |
| `lrc_parser.py` | Ubah teks format LRC jadi daftar `(waktu, teks)`, plus pencarian baris aktif. |
| `player_state.py` | Status play/pause/posisi/offset, thread-safe, dibagi ke GUI & thread Spout. |
| `spout_output.py` | Render beberapa baris + animasi scroll ke RGBA (Pillow) + kirim ke Spout (SpoutGL/pygame/OpenGL). Kelas utamanya `MultiLineLyricRenderer`. |
| `app.py` | GUI Tkinter yang menyatukan semuanya. |
| `main.py` | Entry point (`python main.py`). |

## Kustomisasi cepat

- **Warna teks / outline** — edit parameter `MultiLineLyricRenderer` di
  `spout_output.py` (`text_color`, `outline_color`, `outline_width`).
- **Posisi vertikal keseluruhan** — `vertical_anchor_ratio` (0.0 = atas,
  0.5 = tengah/default, 1.0 = bawah).
- **Jumlah baris konteks** — `context_before` / `context_after` saat
  membuat `SpoutOutputThread` (default masing-masing 2 baris).
- **Kecepatan & gaya scroll** — `transition_ms` (durasi animasi
  perpindahan baris, default 550ms), serta `size_falloff` /
  `opacity_falloff` di `MultiLineLyricRenderer` untuk mengatur seberapa
  cepat baris di sekitar baris aktif mengecil/memudar.
- **Font kustom** — set `font_path` saat membuat `SpoutOutputThread`
  di `app.py`, arahkan ke file `.ttf` pilihanmu (mis. font brand event
  kamu).
- **Frame rate output** — parameter `fps` di `SpoutOutputThread`
  (default 30; frame cuma benar-benar digambar ulang saat baris aktif
  berganti atau sedang animasi berjalan, jadi 30fps sudah lebih dari
  cukup dan ringan di CPU saat sedang diam).
- **Kembali ke mode single-line (v0.1)** — kalau untuk visual tertentu
  kamu lebih suka satu baris polos tanpa scroll, set `context_before=0,
  context_after=0` sebagai pendekatan cepat (baris aktif tetap tampil
  sendirian di titik anchor); untuk kontrol lebih rapi, ini titik yang
  disiapkan jadi opsi `layout` di `Template` pada `SRS.md` §5.3.
- **Karaoke per-kata** — arsitektur saat ini highlight di level baris
  (bukan per-kata); untuk upgrade ke situ butuh data timing per-kata,
  yang LRC standar biasanya tidak menyediakannya.

## Troubleshooting

- **"SpoutGL/pygame belum terpasang..."** — jalankan ulang
  `pip install -r requirements.txt` di Windows, pastikan tidak di
  virtual environment yang salah arsitektur (32-bit vs 64-bit).
- **Resolume tidak melihat sender-nya** — pastikan tombol "Mulai kirim
  ke Resolume" sudah ditekan (cek label Status di bawahnya berubah
  jadi "mengirim ke Resolume sebagai Spout sender '...'"), dan window
  kecil pygame-nya belum kamu tutup.
- **Lirik tidak ketemu di LRCLIB** — coba judul lagu tanpa embel-embel
  seperti "(Official Video)", atau kosongkan field artis dulu untuk
  pencarian lebih longgar.
- **Teks kepotong / terlalu besar** — turunkan Font size, atau
  perbesar Ukuran (resolusi) output.
