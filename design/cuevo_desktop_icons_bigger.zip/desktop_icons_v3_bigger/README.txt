CUEVO Desktop Icons - Bigger Artwork

Variants:
1) extra-tight  -> Logo hijau tanpa latar, padding hampir nol (ikon tampak lebih besar).
2) squircle-badge -> Latar rounded-square hijau brand (65, 184, 131) + logo putih, mengisi kanvas seperti ikon modern.

Tips:
- macOS: convert .iconset ke .icns
    iconutil -c icns macos.iconset -o AppIcon.icns
- Jika masih terasa kecil di dock kamu, coba varian "squircle-badge".